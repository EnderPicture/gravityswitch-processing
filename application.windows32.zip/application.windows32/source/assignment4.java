import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.Map; 
import ddf.minim.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class assignment4 extends PApplet {





// keycodes
private final int UP_KEY    = 38;
private final int LEFT_KEY  = 37;
private final int DOWN_KEY  = 40;
private final int RIGHT_KEY = 39;
private final int SHIFT_KEY = 16;
private final int Z_KEY     = 90;
private final int X_KEY     = 88;
private final int C_KEY     = 67;

// stores the world
World world;

// 60fps physics over here
int physicsTiming = 1000/60;
// when does the next physics calculation happen?
int nextPhysicsCal;

// how many times to update physics this frame?
int updatePhysics;

// all of the key booleans
boolean upHold,downHold,leftHold,rightHold,zHold,xHold,cHold,shiftHold;

// the color that changes every frame. it is the color you see on screen.
int dynamicColor;
// the speed the colour changes
float colorChangeSpeed;

// the font that every thing is going to use.
PFont font;

// start up pause screen text.
String intro = "Arrow keys to Move,\nZ to Pause\nand dismiss menus,\nX to return to\npervious checkpoint.";
String introButton = "start";

// the locations of checkpoints
CheckPoint[] checkpoints;
// which check point the player has passed?
int checkpointState = -1;

Minim minim;
AudioPlayer bgMusic;
AudioPlayer bgMusicTIN;
AudioPlayer landSound;

public void setup() {
  

  // I like stuff to be drawn in the center
  rectMode(CENTER);
  imageMode(CENTER);

  // max framerate, do how much the computer can do.
  frameRate(1000);

  // This game does not do strokes thanyou very much
  noStroke();

  // load minim
  minim = new Minim(this);
  // load all the sounds
  bgMusic = minim.loadFile("The Impossible Game OST Level 1,2,3 and 4 Music.mp3");
  bgMusicTIN = minim.loadFile("The Impossible Game OST Level 1,2,3 and 4 MusicSLOWANDTINNY.mp3");
  landSound = minim.loadFile("LandSound.wav");

  // make new world
  world = new World();
  // turn on the loading menu
  world.menuLoading.on = true;

  // the font wont change, so why not just set it in the constructor
  font = loadFont("PressStart2P-Regular-100.vlw");
  textFont(font);

  // the speed the colour changes
  colorChangeSpeed = 0.01f;

  // set the next physics calculation timing
  nextPhysicsCal = millis()+physicsTiming;
}

public void draw() {
  // set the title bar with game name and FPS
  surface.setTitle("GravitySwitch   FPS: "+frameRate);
  // println(frameRate);
  // scale(0.25);
  // translate(width,height);

  updateMilisecondDelta();

  // calculate the next dynamic color
  dynamicColor = dynamicColorCalc(colorChangeSpeed);
  // update the world
  world.update();
}

/**
 * Calculates the dynamic dynamic colours you see on screen switching
 * it does it by changing the colour mode to HSB, rotationg it by millis()*X
 * it then resotres the to the RGB 255 colour mode.
 * @param speed_ the speed that the color changes where 0 is no change.
 * @return color the calculated color.
 */
public int dynamicColorCalc(float speed_) {
  colorMode(HSB, 360, 100, 100);
  int c = color(millis()*speed_%360,100,100);
  colorMode(RGB, 255, 255, 255);

  c = red(c) > 200 ? color(200,green(c),blue(c)) : c;

  return c;
}

/**
 * Calculates how many times the physics engine should calculate
 * physics
 */
public void updateMilisecondDelta() {
  if (nextPhysicsCal < millis()) {
    updatePhysics = (millis()-nextPhysicsCal)/physicsTiming;
    // println(updatePhysics);
    nextPhysicsCal += updatePhysics*physicsTiming;
  } else {
    updatePhysics = 0;
  }
}

/**
 * Keyboard binding pressed
 */
public void keyPressed() {
  switch (keyCode) {
    case UP_KEY:
      upHold = true;
      break;
    case LEFT_KEY:
      leftHold = true;
      break;
    case DOWN_KEY:
      downHold = true;
      break;
    case RIGHT_KEY:
      rightHold = true;
      break;
    case SHIFT_KEY:
      shiftHold = true;
      break;
    case Z_KEY:
      zHold = true;
      break;
    case X_KEY:
      xHold = true;
      break;
    case C_KEY:
      cHold = true;
      break;
  }
}

/**
 * Keyboard binding released
 */
public void keyReleased() {
  switch (keyCode) {
    case UP_KEY:
      upHold = false;
      break;
    case LEFT_KEY:
      leftHold = false;
      break;
    case DOWN_KEY:
      downHold = false;
      break;
    case RIGHT_KEY:
      rightHold = false;
      break;
    case SHIFT_KEY:
      shiftHold = false;
      break;
    case Z_KEY:
      zHold = false;
      break;
    case X_KEY:
      xHold = false;
      break;
    case C_KEY:
      cHold = false;
      break;
  }
}


// isn't this just the jankiest thing ever... used to be in the world.lr.level reder.
// yes yes, I know it looks ugly. lots word.lr. What can I do? Manual java threading with Runnables and handlers?
/**
* This level reader reads a level image file then, saves the finished level 2D
* aray into the LevelReader's temp Level array.
*/
public void readLevel() {

  world.lr.img = loadImage(world.lr.levelFileName);
  world.lr.img.loadPixels();

  // because image loading takes more time, it should weigh more on the progress bar
  int imageLoadingWeight = 10000;

  world.lr.finishingPoint = world.lr.platformFramesFNum*imageLoadingWeight+
                   world.lr.platformOFramesFNum*imageLoadingWeight+
                   world.lr.platformSFramesFNum*imageLoadingWeight+
                   world.lr.checkPointSaveFNum*imageLoadingWeight+
                   (world.lr.img.height/world.lr.TILE_SIZE) *
                   (world.lr.img.width/world.lr.TILE_SIZE)+
                   world.lr.img.width*world.lr.img.height;


  // making center memory location for all platforms
  world.lr.platformFrames = new PImage[world.lr.platformFramesFNum];
  for (int c = 0; c < world.lr.platformFrames.length; c++) {
    world.lr.platformFrames[c] = loadImage(world.lr.platformFileName+nf(c,5)+".png");
    world.lr.doneCount+=imageLoadingWeight;
  }

  // making center memory location for all platforms
  world.lr.platformOFrames = new PImage[world.lr.platformOFramesFNum];
  for (int c = 0; c < world.lr.platformOFrames.length; c++) {
    world.lr.platformOFrames[c] = loadImage(world.lr.platformOFileName+nf(c,5)+".png");
    world.lr.doneCount+=imageLoadingWeight;
  }

  // mating center memory location for all platformS
  world.lr.platformSFrames = new PImage[world.lr.platformSFramesFNum];
  for (int c = 0; c < world.lr.platformSFrames.length; c++) {
    world.lr.platformSFrames[c] = loadImage(world.lr.platformSFileName+nf(c,5)+".png");
    world.lr.doneCount+=imageLoadingWeight;
  }

  // save spot
  world.lr.checkPointSave = new PImage[world.lr.checkPointSaveFNum];
  for (int c = 0; c < world.lr.checkPointSave.length; c++) {
    world.lr.checkPointSave[c] = loadImage(world.lr.checkPointSaveName+nf(c,5)+".png");
    world.lr.doneCount+=imageLoadingWeight;
  }

  HashMap<Integer,CheckPoint> tempCheckPoints = new HashMap<Integer,CheckPoint>();

  // convert pixel array into a 2D array. easier to work with
  int[][] map = new int[world.lr.img.width][world.lr.img.height];
  world.lr.level = new Actor[world.lr.img.width/world.lr.TILE_SIZE][world.lr.img.height/world.lr.TILE_SIZE];

  for (int c = 0; c < world.lr.img.width*world.lr.img.height; c++) {
    int x = c % world.lr.img.width;
    int y = c/world.lr.img.width;

    world.lr.doneCount++;

    map[x][y] = world.lr.img.pixels[c];
  }

  // go through the 2D array
  for (int y = 0; y < world.lr.img.height; y += world.lr.TILE_SIZE) {
    for (int x = 0; x < world.lr.img.width; x += world.lr.TILE_SIZE) {
      world.lr.doneCount++;
      if (map[x+1][y+1] != world.lr.blank) {
        if (map[x+1][y+1] == world.lr.normalBlock) {
          // normal collision active block

          float pX = x/world.lr.TILE_SIZE*world.lr.platformSize*2-world.lr.img.width/world.lr.TILE_SIZE*world.lr.platformSize;
          float pY = y/world.lr.TILE_SIZE*world.lr.platformSize*2-world.lr.img.height/world.lr.TILE_SIZE*world.lr.platformSize;
          float rotation = 0;

          if (map[x][y] == world.lr.positive || map[x+2][y] == world.lr.positive || map[x][y+2] == world.lr.positive || map[x+2][y+2] == world.lr.positive ||
              map[x][y] == world.lr.negative || map[x+2][y] == world.lr.negative || map[x][y+2] == world.lr.negative || map[x+2][y+2] == world.lr.negative) {
            // this is a 45 degrees slant block

            boolean gravity = false;

            if (map[x][y] == world.lr.positive) {
              // top left
              pX -= world.lr.platformSize/2;
              pY -= world.lr.platformSize/2;
              rotation = PI/2 + PI/4;
              gravity = true;
            } else if (map[x+2][y] == world.lr.positive) {
              // top right
              pX += world.lr.platformSize/2;
              pY -= world.lr.platformSize/2;
              rotation = PI + PI/4;
              gravity = true;
            } else if (map[x][y+2] == world.lr.positive) {
              // bottom left
              pX -= world.lr.platformSize/2;
              pY += world.lr.platformSize/2;
              rotation = PI/4;
              gravity = true;
            } else if (map[x+2][y+2] == world.lr.positive) {
              // bottom right
              pX += world.lr.platformSize/2;
              pY += world.lr.platformSize/2;
              rotation = PI + PI/2 + PI/4;
              gravity = true;
            } else if (map[x][y] == world.lr.negative) {
              // top left no gravity
              pX -= world.lr.platformSize/2;
              pY -= world.lr.platformSize/2;
              rotation = PI/2 + PI/4;
            } else if (map[x+2][y] == world.lr.negative) {
              // top right no gravity
              pX += world.lr.platformSize/2;
              pY -= world.lr.platformSize/2;
              rotation = PI + PI/4;
            } else if (map[x][y+2] == world.lr.negative) {
              // bottom left no gravity
              pX -= world.lr.platformSize/2;
              pY += world.lr.platformSize/2;
              rotation = PI/4;
            } else if (map[x+2][y+2] == world.lr.negative) {
              // bottom right no gravity
              pX += world.lr.platformSize/2;
              pY += world.lr.platformSize/2;
              rotation = PI + PI/2 + PI/4;
            }

            int fpa = 30;
            int frameStart = 0;
            int frameEnd = 0;

            if (gravity) {
              frameStart = 0;
              frameEnd = frameStart+fpa-1;
            } else {
              frameStart = fpa;
              frameEnd = fpa;
            }

            Platform p = new Platform(pX,pY,rotation,frameStart, frameEnd, world.lr.platformSFrames);
            // Platform p = new Platform(pX,pY,rotation);

            if (gravity) {
              p.gTop = true;
            }

            float slantSizeW = new PVector((world.lr.platformSize-world.lr.cBoxDelta),(world.lr.platformSize-world.lr.cBoxDelta)).mag();
            float slantSizeH = new PVector((world.lr.platformSize-world.lr.cBoxDelta)/2,(world.lr.platformSize-world.lr.cBoxDelta)/2).mag();

            p.cTop = slantSizeH;
            p.cBottom = slantSizeH;
            p.cLeft = slantSizeW-1;
            p.cRight = slantSizeW-1;





            world.lr.level[x/world.lr.TILE_SIZE][y/world.lr.TILE_SIZE] = p;


          } else if (map[x][y] == world.lr.death) {
            // does the same thing, but this is a death block, so the tag will be DEATH
            int fpa = 30;
            int frameStart = 15*fpa;
            int frameEnd = frameStart;


            Platform p = new Platform(pX,pY,rotation,frameStart+1, frameEnd+1, world.lr.platformFrames);

            p.cTop = world.lr.platformSize-world.lr.cBoxDelta;
            p.cBottom = world.lr.platformSize-world.lr.cBoxDelta;
            p.cLeft = world.lr.platformSize-world.lr.cBoxDelta;
            p.cRight = world.lr.platformSize-world.lr.cBoxDelta;

            p.tag = "DEATH";

            world.lr.level[x/world.lr.TILE_SIZE][y/world.lr.TILE_SIZE] = p;

          } else if (map[x+1][y] == world.lr.positiveO || map[x][y+1] == world.lr.positiveO || map[x+2][y+1] == world.lr.positiveO || map[x+1][y+2] == world.lr.positiveO) {

            // this is a reverse gravity block

            // framesPerAnimation
            int fpa = 30;

            // frame start end as defaults
            int frameStart = 0;
            int frameEnd = 0;

            // default gravity setting
            boolean gTop = false;
            boolean gBottom = false;
            boolean gLeft = false;
            boolean gRight = false;

            // check for gravity
            if (map[x+1][y] == world.lr.positiveO)
            gTop = true;
            if (map[x+1][y+2] == world.lr.positiveO)
            gBottom = true;
            if (map[x][y+1] == world.lr.positiveO)
            gLeft = true;
            if (map[x+2][y+1] == world.lr.positiveO)
            gRight = true;

            // 16 ways T B L R can form, select the right range of frames
            if (gTop && gRight && gBottom && gLeft) {
              frameStart = 0;
              frameEnd = frameStart+fpa-1;
            } else if (!gTop && gRight && gBottom && gLeft) {
              frameStart = fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gTop && !gRight && gBottom && gLeft) {
              frameStart = 2*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gTop && gRight && !gBottom && gLeft) {
              frameStart = 3*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gTop && gRight && gBottom && !gLeft) {
              frameStart = 4*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (!gTop && !gRight && gBottom && gLeft) {
              frameStart = 5*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gTop && !gRight && !gBottom && gLeft) {
              frameStart = 6*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gTop && gRight && !gBottom && !gLeft) {
              frameStart = 7*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (!gTop && gRight && gBottom && !gLeft) {
              frameStart = 8*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (!gTop && gRight && !gBottom && gLeft) {
              frameStart = 9*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gTop && !gRight && gBottom && !gLeft) {
              frameStart = 10*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gTop) {
              frameStart = 11*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gRight) {
              frameStart = 12*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gBottom) {
              frameStart = 13*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gLeft) {
              frameStart = 14*fpa;
              frameEnd = frameStart+fpa-1;
            } else {
              frameStart = 15*fpa;
              frameEnd = frameStart;
            }

            Platform p = new Platform(pX,pY,rotation,frameStart, frameEnd, world.lr.platformOFrames);

            // set it to the normal size of collision
            p.cTop = world.lr.platformSize-world.lr.cBoxDelta;
            p.cBottom = world.lr.platformSize-world.lr.cBoxDelta;
            p.cLeft = world.lr.platformSize-world.lr.cBoxDelta;
            p.cRight = world.lr.platformSize-world.lr.cBoxDelta;

            // set the gravity faces
            p.gTop = gTop;
            p.gBottom = gBottom;
            p.gLeft = gLeft;
            p.gRight = gRight;

            // tag it with O so the platform knows what it is
            p.tag = ("O");

            world.lr.level[x/world.lr.TILE_SIZE][y/world.lr.TILE_SIZE] = p;

          } else {

            // this is a normal block, so make a new platform

            // framesPerAnimation
            int fpa = 30;

            int frameStart = 0;
            int frameEnd = 0;


            boolean gTop = false;
            boolean gBottom = false;
            boolean gLeft = false;
            boolean gRight = false;


            if (map[x+1][y] == world.lr.positive)
            gTop = true;
            if (map[x+1][y+2] == world.lr.positive)
            gBottom = true;
            if (map[x][y+1] == world.lr.positive)
            gLeft = true;
            if (map[x+2][y+1] == world.lr.positive)
            gRight = true;

            // 16 ways T B L R can form, select the right range of frames
            if (gTop && gRight && gBottom && gLeft) {
              frameStart = 0;
              frameEnd = frameStart+fpa-1;
            } else if (!gTop && gRight && gBottom && gLeft) {
              frameStart = fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gTop && !gRight && gBottom && gLeft) {
              frameStart = 2*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gTop && gRight && !gBottom && gLeft) {
              frameStart = 3*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gTop && gRight && gBottom && !gLeft) {
              frameStart = 4*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (!gTop && !gRight && gBottom && gLeft) {
              frameStart = 5*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gTop && !gRight && !gBottom && gLeft) {
              frameStart = 6*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gTop && gRight && !gBottom && !gLeft) {
              frameStart = 7*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (!gTop && gRight && gBottom && !gLeft) {
              frameStart = 8*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (!gTop && gRight && !gBottom && gLeft) {
              frameStart = 9*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gTop && !gRight && gBottom && !gLeft) {
              frameStart = 10*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gTop) {
              frameStart = 11*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gRight) {
              frameStart = 12*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gBottom) {
              frameStart = 13*fpa;
              frameEnd = frameStart+fpa-1;
            } else if (gLeft) {
              frameStart = 14*fpa;
              frameEnd = frameStart+fpa-1;
            } else {
              frameStart = 15*fpa;
              frameEnd = frameStart;
            }

            Platform p = new Platform(pX,pY,rotation,frameStart, frameEnd, world.lr.platformFrames);

            // set it to the normal size of collision
            p.cTop = world.lr.platformSize-world.lr.cBoxDelta;
            p.cBottom = world.lr.platformSize-world.lr.cBoxDelta;
            p.cLeft = world.lr.platformSize-world.lr.cBoxDelta;
            p.cRight = world.lr.platformSize-world.lr.cBoxDelta;


            p.gTop = gTop;
            p.gBottom = gBottom;
            p.gLeft = gLeft;
            p.gRight = gRight;



            world.lr.level[x/world.lr.TILE_SIZE][y/world.lr.TILE_SIZE] = p;
          }

        } else if (map[x+1][y+1] == world.lr.noCBlock) {

          float pX = x/world.lr.TILE_SIZE*world.lr.platformSize*2-world.lr.img.width/world.lr.TILE_SIZE*world.lr.platformSize;
          float pY = y/world.lr.TILE_SIZE*world.lr.platformSize*2-world.lr.img.height/world.lr.TILE_SIZE*world.lr.platformSize;
          float rotation = 0;

          Platform p = new Platform(pX,pY,rotation,450, 450, world.lr.platformFrames);
          p.collisionMode = p.NOC;

          world.lr.level[x/world.lr.TILE_SIZE][y/world.lr.TILE_SIZE] = p;

        } else if (map[x+1][y+1] == world.lr.checkpointFlag) {
          // this is a check point flag OBJECT
          float pX = x/world.lr.TILE_SIZE*world.lr.platformSize*2-world.lr.img.width/world.lr.TILE_SIZE*world.lr.platformSize;
          float pY = y/world.lr.TILE_SIZE*world.lr.platformSize*2-world.lr.img.height/world.lr.TILE_SIZE*world.lr.platformSize;
          float rotation = 0;
          int checkPointNum = 0;
          // check in which direction should the flag be at.
          // the read channel incodes the checkPoint ID. So grab that real quick
          if (map[x+1][y] != world.lr.blank && map[x+1][y] != world.lr.outlineGray) {
            // red channel
            checkPointNum = (map[x+1][y] >> 16) & 0xFF;
            rotation = PI;
          }
          else if (map[x+1][y+2] != world.lr.blank && map[x+1][y+2] != world.lr.outlineGray) {
            // red channel
            checkPointNum = (map[x+1][y+2] >> 16) & 0xFF;
            rotation = 0;
          }
          else if (map[x][y+1] != world.lr.blank && map[x][y+1] != world.lr.outlineGray) {
            // red channel
            checkPointNum = (map[x][y+1] >> 16) & 0xFF;
            rotation = PI/2;
          }
          else if (map[x+2][y+1] != world.lr.blank && map[x+2][y+1] != world.lr.outlineGray) {
            // red channel
            checkPointNum = (map[x+2][y+1] >> 16) & 0xFF;
            rotation = PI+PI/2;
          }

          Platform p = new Platform(pX,pY,rotation,0, world.lr.checkPointSave.length-1, world.lr.checkPointSave);

          // set the collisionMode to trigger
          p.collisionMode = p.TRIGGERC;

          // tag the platform with the checkpoint ID
          p.tag = checkPointNum+"";

          p.cTop = world.lr.platformSize-world.lr.cBoxDelta;
          p.cBottom = world.lr.platformSize-world.lr.cBoxDelta;
          p.cLeft = world.lr.platformSize-world.lr.cBoxDelta;
          p.cRight = world.lr.platformSize-world.lr.cBoxDelta;

          // this is so that the game can look back in order of from 0 to # where the check points are.
          CheckPoint c = new CheckPoint(p.loc.copy(),p.angle);
          tempCheckPoints.put(checkPointNum,c);


          world.lr.level[x/world.lr.TILE_SIZE][y/world.lr.TILE_SIZE] = p;
        } else if (map[x+1][y+1] == world.lr.coin) {
          // this is a coin OBJECT
          float pX = x/world.lr.TILE_SIZE*world.lr.platformSize*2-world.lr.img.width/world.lr.TILE_SIZE*world.lr.platformSize;
          float pY = y/world.lr.TILE_SIZE*world.lr.platformSize*2-world.lr.img.height/world.lr.TILE_SIZE*world.lr.platformSize;
          // make coin with coin image
          Coin c = new Coin(pX, pY, world.lr.coinImage);
          world.lr.level[x/world.lr.TILE_SIZE][y/world.lr.TILE_SIZE] = c;
        } else if (map[x+1][y+1] == world.lr.win) {
          // this is a win block
          float pX = x/world.lr.TILE_SIZE*world.lr.platformSize*2-world.lr.img.width/world.lr.TILE_SIZE*world.lr.platformSize;
          float pY = y/world.lr.TILE_SIZE*world.lr.platformSize*2-world.lr.img.height/world.lr.TILE_SIZE*world.lr.platformSize;

          Platform p = new Platform(pX,pY,0,450, 450, world.lr.platformFrames);

          // set it to the normal size of collision
          p.cTop = world.lr.platformSize-world.lr.cBoxDelta;
          p.cBottom = world.lr.platformSize-world.lr.cBoxDelta;
          p.cLeft = world.lr.platformSize-world.lr.cBoxDelta;
          p.cRight = world.lr.platformSize-world.lr.cBoxDelta;

          // no gravity at all please
          p.gTop = false;
          p.gBottom = false;
          p.gLeft = false;
          p.gRight = false;

          // set tag as WIN so the player can know.
          p.tag = ("WIN");

          world.lr.level[x/world.lr.TILE_SIZE][y/world.lr.TILE_SIZE] = p;
        }
      }
    }
  }

  // save the new checkpoint list into array
  checkpoints = new CheckPoint[tempCheckPoints.size()];
  for (int c = 0; c < tempCheckPoints.size(); c++) {
    checkpoints[c] = tempCheckPoints.get(c);
  }

  // set the pause menu to the intro menu.
  world.menuPause.text = intro;
  world.menuPause.b.text = introButton;
  world.menuPause.on = true;
}
/**
* To be used when box collision with rotation is needed
*
* @author  Donny Wu
* @version 1.0
*/
class Actor extends GameObject{

  // collision mode with all its modes under as FINALS
  int collisionMode;

  final int NORMC = 0;
  final int TRIGGERC = 1;
  final int NOC = 2;

  float cRight, cLeft, cTop, cBottom;

  // face codes on which face did the object hit
  final int TOP_FACE = 1;
  final int RIGHT_FACE = 2;
  final int BOTTOM_FACE = 3;
  final int LEFT_FACE = 4;

  // if the object is grounded
  boolean grounded;

  // temp collison objects, cleared every frame
  ArrayList<Platform> collidedPlatforms;
  // temp trigger objects, cleared every frame
  ArrayList<Platform> triggerObjects;
  // basically, how much push back collision should do
  float deltaColision;
  // which face of this object did b collided with.
  int aSideCollided;
  // which face of the other object did this object collided with.
  int bSideCollided;

  // the gravityDirection in rad
  float gravityDirection;

  /**
   * Starts an actor up at 00
   */
  Actor() {
    super();
    // default collision box;
    cTop = 50;
    cBottom = 50;
    cLeft = 50;
    cRight = 50;

    collidedPlatforms = new ArrayList<Platform>();
    triggerObjects = new ArrayList<Platform>();
  }

  /**
   * Star an actor up with location
   * @param x_ the X locaiton of the new actor
   * @param y_ the Y locaiton of the new actor
   */
  Actor(float x_, float y_) {
    super(x_,y_);
    // default collision box;
    cTop = 50;
    cBottom = 50;
    cLeft = 50;
    cRight = 50;

    collidedPlatforms = new ArrayList<Platform>();
    triggerObjects = new ArrayList<Platform>();
  }

  /**
   * Star an actor up with location and an name for animations
   * @param x_ the X locaiton of the new actor
   * @param y_ the Y locaiton of the new actor
   * @param minFrame_ where the frame gatherer should start its image grabbing
   * @param maxFrame_ where the frame gatherer should end its image grabbing
   * @param fileName_ the file path to the image files. has to be in "fileName_"+00000.png format
   */
  Actor(float x_, float y_, int minFrame_, int maxFrame_, String fileName_) {
    super(x_, y_, minFrame_, maxFrame_, fileName_);
    // default collision box;
    cTop = 50;
    cBottom = 50;
    cLeft = 50;
    cRight = 50;

    collidedPlatforms = new ArrayList<Platform>();
    triggerObjects = new ArrayList<Platform>();
  }

  /**
   * Star an actor up with location and the usage of image array reference
   * @param x_ the X locaiton of the new actor
   * @param y_ the Y locaiton of the new actor
   * @param minFrame_ the min frame the actor can use from the image array
   * @param maxFrame_ the max frame the actor can use from the image array
   * @param frames_ the preloaded image array
   */
  Actor(float x_, float y_, int minFrame_, int maxFrame_, PImage[] frames_) {
    super(x_, y_, minFrame_, maxFrame_, frames_);
    // default collision box;
    cTop = 50;
    cBottom = 50;
    cLeft = 50;
    cRight = 50;

    collidedPlatforms = new ArrayList<Platform>();
    triggerObjects = new ArrayList<Platform>();
  }


  /**
   * Star an actor up with location and the usage of image array reference
   * @param b_ the object actor is trying to check the collision to
   * @return boolean that is true if it has collided
   */
  public boolean collision(Actor b_) {
    float aVel1, aVel2, aVel3, aVel4, bVel1, bVel2, bVel3, bVel4, avb, bva, minDelta;
    PVector roedACBoxTR, roedACBoxTL, roedACBoxBR, roedACBoxBL, roedBCBoxTR, roedBCBoxTL, roedBCBoxBR, roedBCBoxBL;

    Actor b = b_;

    // stores the smallest delta
    deltaColision = MAX_FLOAT;
    minDelta = MAX_FLOAT;

    // Rotated locations for each of the angles
    PVector aLocRotatedA = loc.copy().rotate(-angle);
    PVector bLocRotatedA = b.loc.copy().rotate(-angle);

    PVector aLocRotatedB = loc.copy().rotate(-b.angle);
    PVector bLocRotatedB = b.loc.copy().rotate(-b.angle);

    // Collision boxes
    PVector aCBoxTR = new PVector(cRight,-cTop);
    PVector aCBoxTL = new PVector(-cLeft,-cTop);
    PVector aCBoxBR = new PVector(cRight,cBottom);
    PVector aCBoxBL = new PVector(-cLeft,cBottom);

    PVector bCBoxTR = new PVector(b.cRight,-b.cTop);
    PVector bCBoxTL = new PVector(-b.cLeft,-b.cTop);
    PVector bCBoxBR = new PVector(b.cRight,b.cBottom);
    PVector bCBoxBL = new PVector(-b.cLeft,b.cBottom);

    // a's planes
    // rotate the collision b's collisoin box to match
    roedBCBoxTR = bCBoxTR.copy().rotate(-angle+b.angle);
    roedBCBoxTL = bCBoxTL.copy().rotate(-angle+b.angle);
    roedBCBoxBR = bCBoxBR.copy().rotate(-angle+b.angle);
    roedBCBoxBL = bCBoxBL.copy().rotate(-angle+b.angle);
    // a's x plane

    aVel1 = aCBoxTR.x + aLocRotatedA.x;
    aVel2 = aCBoxTL.x + aLocRotatedA.x;
    aVel3 = aCBoxBR.x + aLocRotatedA.x;
    aVel4 = aCBoxBL.x + aLocRotatedA.x;

    bVel1 = roedBCBoxTR.x + bLocRotatedA.x;
    bVel2 = roedBCBoxTL.x + bLocRotatedA.x;
    bVel3 = roedBCBoxBR.x + bLocRotatedA.x;
    bVel4 = roedBCBoxBL.x + bLocRotatedA.x;

    float[] aXAVels = {aVel1, aVel2, aVel3, aVel4};
    float[] aXBVels = {bVel1, bVel2, bVel3, bVel4};

    avb = max(aXAVels) - min(aXBVels);
    bva = max(aXBVels) - min(aXAVels);

    if (avb < minDelta) {
      minDelta = avb;
      aSideCollided = LEFT_FACE;
    }
    if (bva < minDelta) {
      minDelta = bva;
      aSideCollided = RIGHT_FACE;
    }

    // collided?
    boolean aXC = avb > 0 && bva > 0;
    if (!aXC)
      return false;
    else {
      if (avb < deltaColision)
      deltaColision = avb;
      if (bva < deltaColision)
      deltaColision = bva;
    }

    // a's y plane
    aVel1 = aCBoxTR.y + aLocRotatedA.y;
    aVel2 = aCBoxTL.y + aLocRotatedA.y;
    aVel3 = aCBoxBR.y + aLocRotatedA.y;
    aVel4 = aCBoxBL.y + aLocRotatedA.y;

    bVel1 = roedBCBoxTR.y + bLocRotatedA.y;
    bVel2 = roedBCBoxTL.y + bLocRotatedA.y;
    bVel3 = roedBCBoxBR.y + bLocRotatedA.y;
    bVel4 = roedBCBoxBL.y + bLocRotatedA.y;

    float[] aYAVels = {aVel1, aVel2, aVel3, aVel4};
    float[] aYBVels = {bVel1, bVel2, bVel3, bVel4};

    avb = max(aYAVels) - min(aYBVels);
    bva = max(aYBVels) - min(aYAVels);

    // println("LEFT/TOP:"+avb+" RIGHT/BOTTOM:"+bva);

    if (avb < minDelta) {
      minDelta = avb;
      aSideCollided = TOP_FACE;
    }
    if (bva < minDelta) {
      minDelta = bva;
      aSideCollided = BOTTOM_FACE;
    }

    // collided?
    boolean aYC = avb > 0 && bva > 0;
    if (!aYC)
      return false;
    else {
      if (avb < deltaColision)
      deltaColision = avb;
      if (bva < deltaColision)
      deltaColision = bva;
    }

    // reset minDelta so it will work again for b's planes
    minDelta = MAX_FLOAT;

    // b's planes
    // rotate the collision a's collisoin box to match
    roedACBoxTR = aCBoxTR.copy().rotate(-b.angle+angle);
    roedACBoxTL = aCBoxTL.copy().rotate(-b.angle+angle);
    roedACBoxBR = aCBoxBR.copy().rotate(-b.angle+angle);
    roedACBoxBL = aCBoxBL.copy().rotate(-b.angle+angle);
    // b's x plane

    bVel1 = bCBoxTR.x + bLocRotatedB.x;
    bVel2 = bCBoxTL.x + bLocRotatedB.x;
    bVel3 = bCBoxBR.x + bLocRotatedB.x;
    bVel4 = bCBoxBL.x + bLocRotatedB.x;

    aVel1 = roedACBoxTR.x + aLocRotatedB.x;
    aVel2 = roedACBoxTL.x + aLocRotatedB.x;
    aVel3 = roedACBoxBR.x + aLocRotatedB.x;
    aVel4 = roedACBoxBL.x + aLocRotatedB.x;

    float[] bXAVels = {aVel1, aVel2, aVel3, aVel4};
    float[] bXBVels = {bVel1, bVel2, bVel3, bVel4};

    avb = max(bXAVels) - min(bXBVels);
    bva = max(bXBVels) - min(bXAVels);
    if (avb < minDelta) {
      minDelta = avb;
      bSideCollided = LEFT_FACE;
    }
    if (bva < minDelta) {
      minDelta = bva;
      bSideCollided = RIGHT_FACE;
    }

    // collided?
    boolean bXC = avb > 0 && bva > 0;
    if (!bXC)
      return false;
    else {
      if (avb < deltaColision)
      deltaColision = avb;
      if (bva < deltaColision)
      deltaColision = bva;
    }


    // b's y plane
    bVel1 = bCBoxTR.y + bLocRotatedB.y;
    bVel2 = bCBoxTL.y + bLocRotatedB.y;
    bVel3 = bCBoxBR.y + bLocRotatedB.y;
    bVel4 = bCBoxBL.y + bLocRotatedB.y;

    aVel1 = roedACBoxTR.y + aLocRotatedB.y;
    aVel2 = roedACBoxTL.y + aLocRotatedB.y;
    aVel3 = roedACBoxBR.y + aLocRotatedB.y;
    aVel4 = roedACBoxBL.y + aLocRotatedB.y;


    float[] bYAVels = {aVel1, aVel2, aVel3, aVel4};
    float[] bYBVels = {bVel1, bVel2, bVel3, bVel4};

    avb = max(bYAVels) - min(bYBVels);
    bva = max(bYBVels) - min(bYAVels);
    if (avb < minDelta) {
      minDelta = avb;
      bSideCollided = TOP_FACE;
    }
    if (bva < minDelta) {
      minDelta = bva;
      bSideCollided = BOTTOM_FACE;
    }

    // collided?
    boolean bYC = avb > 0 && bva > 0;
    if (!bYC)
      return false;
    else {
      if (avb < deltaColision)
      deltaColision = avb;
      if (bva < deltaColision)
      deltaColision = bva;
    }


    return aXC && aYC && bXC && bYC;

  }

  /**
   * For use when object needs to collide with platforms.
   * switches gravity automatically and sends the trigger objects into the arraylist
   * also sends the collided platforms into the arraylist as well.
   */
  public void collisionController() {

    // clear all the temp reference arraylists so it can be used again.
    collidedPlatforms.clear();
    triggerObjects.clear();

    grounded = false;

    for(int c = 0; c < world.platforms.size(); c ++) {
      Platform p = world.platforms.get(c);
      if (collision(p)) {
        if (p.collisionMode == NORMC) {
          // if the the platform is colliding with THIS, add it to the collidedPlatforms list
          collidedPlatforms.add(p);

          float pushAngle = p.angle;

          if (p.tag != null && p.tag.equals("O")) {
            // opposite day
            // pushes different direction depending on which side is touching.

            if (bSideCollided == TOP_FACE) {
              if (p.gTop) {
                angleDes = pushAngle;
                gravityDirection = pushAngle+PI;
                grounded = true;
              } else {
                grounded = false;
              }
            } else if (bSideCollided == BOTTOM_FACE) {
              pushAngle += PI;
              if (p.gBottom) {
                angleDes = pushAngle;
                gravityDirection = pushAngle+PI;
                grounded = true;
              } else {
                grounded = false;
              }
            } else if (bSideCollided == LEFT_FACE) {
              pushAngle -= PI/2;
              if (p.gLeft) {
                angleDes = pushAngle;
                gravityDirection = pushAngle+PI;
                grounded = true;
              } else {
                grounded = false;
              }
            } else if (bSideCollided == RIGHT_FACE) {
              pushAngle += PI/2;
              if (p.gRight) {
                angleDes = pushAngle;
                gravityDirection = pushAngle+PI;
                grounded = true;
              } else {
                grounded = false;
              }
            } else {
              grounded = false;
            }

          } else {
            // normal gravity blocks
            // pushes different direction depending on which side is touching.

            if (bSideCollided == TOP_FACE) {
              if (p.gTop) {
                angleDes = pushAngle;
                gravityDirection = pushAngle;
                grounded = true;
              } else {
                grounded = false;
              }
            } else if (bSideCollided == BOTTOM_FACE){
              pushAngle += PI;
              if (p.gBottom) {
                angleDes = pushAngle;
                gravityDirection = pushAngle;
                grounded = true;
              } else {
                grounded = false;
              }
            } else if (bSideCollided == LEFT_FACE) {
              pushAngle -= PI/2;
              if (p.gLeft) {
                angleDes = pushAngle;
                gravityDirection = pushAngle;
                grounded = true;
              } else {
                grounded = false;
              }
            } else if (bSideCollided == RIGHT_FACE) {
              pushAngle += PI/2;
              if (p.gRight) {
                angleDes = pushAngle;
                gravityDirection = pushAngle;
                grounded = true;
              } else {
                grounded = false;
              }
            } else {
              grounded = false;
            }

          }



          // push the object up to the place it should be
          loc.sub(new PVector(0,deltaColision).rotate(pushAngle));

          // eliminate the velocity that hits
          vel.rotate(-pushAngle);
          vel.y = 0;
          vel.rotate(pushAngle);
        }
        else if (p.collisionMode == TRIGGERC) {
          // add to the trigger arraylist
          triggerObjects.add(p);
        }
      }
    }

  }


  // float roundDes(float num_, int numOfDes_) {
  //   return round(num_ * pow(numOfDes_,numOfDes_)) / pow(numOfDes_,numOfDes_);
  // }
}
/**
* This is a custom button. Did not like that thrid part library as I could not
* dynamically move it, tell it when to render, and follow transltations.
*
* @author  Donny Wu
* @version 1.0
*/
class Button {
  // where is the button being rendered
  PVector renderingLoc;
  // where is the canvas located
  PVector canvasLoc;
  // how big the button is
  PVector size;

  // how much darder will the button be when at those stages
  int hoverButton = 2;
  int holdButton = 3;
  int normalButton = 0;

  // true when mouse is hovering over the button
  boolean hoverOver;

  // true when left mouse buttton is down and is ontop of the button
  boolean pressed;
  // the last postion it was in
  boolean lastPressed;
  // is true in one tick.
  boolean clicked;
  // the temp text that will be replaced but menus that uses this.
  String text = "Hello";

  /**
   * Creates coin at location
   * @param canvasLoc_ x and y loc for canvas' location
   * @param size_ width and height size for the button
   */
  Button (PVector canvasLoc_, PVector size_) {
    canvasLoc = canvasLoc_;
    size = size_;
    renderingLoc = new PVector();
  }

  /**
   * Does all the cecking for button feature
   */
  public void update() {
    // calculates the actual screen location so the mouse can be mapped to the button
    PVector actualScreenLoc = renderingLoc.copy().add(canvasLoc);

    // check if the mouse is hovering over the button
    hoverOver = mouseX < actualScreenLoc.x+size.x/2 && mouseX > actualScreenLoc.x-size.x/2 &&
                mouseY < actualScreenLoc.y+size.y/2 && mouseY > actualScreenLoc.y-size.y/2;

    // check if the button is pressed
    pressed = hoverOver && mousePressed && mouseButton == LEFT;

    /*
    pressed does not mean clicked man. first the button needs to be still over the button
    then the button needs to be pressed in the last frame but it is not in this one.
    this means the click is valid and only happens on the mousebutton released
    */
    clicked = hoverOver && lastPressed && !pressed;

    lastPressed = pressed;
  }

  /**
   * Renders the button at the correct color and darkness
   */
  public void render() {
    // start both colors
    int textColor;
    int buttonColor;

    // will be changed here depending on the state of the button
    if (pressed) {
      textColor = color(red(dynamicColor)/(3+holdButton),green(dynamicColor)/(3+holdButton),blue(dynamicColor)/(3+holdButton));
      buttonColor = color(red(dynamicColor)/holdButton,green(dynamicColor)/holdButton,blue(dynamicColor)/holdButton);
    } else if (hoverOver) {
      textColor = color(red(dynamicColor)/(3+hoverButton),green(dynamicColor)/(3+hoverButton),blue(dynamicColor)/(3+hoverButton));
      buttonColor = color(red(dynamicColor)/hoverButton,green(dynamicColor)/hoverButton,blue(dynamicColor)/hoverButton);
    } else {
      textColor = color(red(dynamicColor)/(3+normalButton),green(dynamicColor)/(3+normalButton),blue(dynamicColor)/(3+normalButton));
      buttonColor = dynamicColor;
    }

    // draw the button over here with text and correct darkness
    pushMatrix();
    translate(canvasLoc.x, canvasLoc.y);
    fill(buttonColor);
    rect(0,0,size.x,size.y);


    fill(textColor);
    textSize(32);
    textAlign(CENTER,CENTER);
    text(text, 0, 0);

    popMatrix();

  }
}
/**
* The camera 2d class does the main translation of the game. acting as a camera moving around
* it does the movements smoothly, thus not 100% on the target all the time.
*
* @author  Donny Wu
* @version 1.0
*/
class Cam2D extends GameObject {
  // how fast the camera moves
  float smoothFactor;

  /**
   * Creates a camera where 0,0 is at the center of the screen
   * Also starts smooth panning
   */
  Cam2D() {
    super(width/2, height/2);

    des = loc.copy();
    smoothFactor = .1f;
  }

  /**
   * Creates a camera where 0,0 is at x,y
   * Also starts smooth panning
   * @param x_ x location for center
   * @param y_ y location for center
   */
  Cam2D(float x_, float y_, float angle_) {
    super(x_, y_, angle_);

    angleDes = angle_;
    des = loc.copy();
    smoothFactor = .1f;
  }

  /**
   * Overrides the default blank gameObject update method
   * Should be ran every game tick
   */
  public @Override
  void update() {
    smoothMove(smoothFactor);
    smoothRotate(smoothFactor);


    for (int c = 0; c < updatePhysics; c++) {
      simplePhysicsCal();
    }

    translate(width/2-width/4,height/2);
    rotate(angle);
    scale(sin(millis()*0.01f)*0.05f+1+0.05f);
    translate(loc.x, loc.y);

  }

}
/**
* this stores the ceckpoint info. populated when loading and at time of crossing
*
* @author  Donny Wu
* @version 1.0
*/
class CheckPoint {
  PVector loc;
  float angle;
  int score;
  int musicLoc;

  /**
   * Creates a camera where 0,0 is at x,y
   * @param loc_ x location for center
   * @param angle_ y location for center
   */
  CheckPoint(PVector loc_,float angle_) {
  loc = loc_;
  angle = angle_;
  }

}
/**
* This is a coin, a trigger object by default
*
* @author  Donny Wu
* @version 1.0
*/
class Coin extends Actor{
  /**
   * Creates coin at location
   * @param x_ x location for coin
   * @param y_ y location for coin
   * @param img_ the image for the coin
   */
  Coin(float x_, float y_, PImage img_) {
    super(x_, y_);

    collisionMode = TRIGGERC;

    cTop = 10;
    cBottom = 10;
    cLeft = 10;
    cRight = 10;

    img = img_;
  }
  /**
   * Updates the coin's angle
   */
  public @Override
  void update() {
    angle = sin(millis()*0.005f)*0.5f;
  }



}
/**
* The GameObject class consists of simple physics calculations and image based animations
*
* @author  Donny Wu
* @version 1.0
*/
class GameObject{

  // physics values
  PVector loc, vel, acc, des;
  // angle valeus
  float angle, angleVel, angleAcc, angleDes;
  // the display image
  PImage img;
  // animation frames
  PImage[] frames;

  // so it can keep track of the last millisecond it changed the frame, frame c is the current frame
  int lastMilAni;
  int frameC;

  boolean centralImgArray;

  // this is for central image array based animatoin
  int minFrame;
  int maxFrame;

  /**
   * Star an game object at 0,0
   */
  GameObject() {
    loc =  new PVector();
    vel =  new PVector();
    acc =  new PVector();
    des =  new PVector();
  }

  /**
   * Star an gameObject up with location
   * @param x_ the X locaiton of the new gameObject
   * @param y_ the Y locaiton of the new gameObject
   */
  GameObject(float x_, float y_) {
    loc =  new PVector(x_, y_);
    vel =  new PVector();
    acc =  new PVector();
    des =  new PVector();
  }

  /**
   * Star an gameObject up with location and angle
   * @param x_ the X locaiton of the new gameObject
   * @param y_ the Y locaiton of the new gameObject
   * @param angle_ the angle the object will be at
   */
  GameObject(float x_, float y_, float angle_) {
    loc =  new PVector(x_, y_);
    vel =  new PVector();
    acc =  new PVector();
    des =  new PVector();
    angle = angle_;
  }

  /**
   * Star an gameObject up with location and an name for animations
   * @param x_ the X locaiton of the new actor
   * @param y_ the Y locaiton of the new actor
   * @param minFrame_ where the frame gatherer should start its image grabbing
   * @param maxFrame_ where the frame gatherer should end its image grabbing
   * @param fileName_ the file path to the image files. has to be in "fileName_"+00000.png format
   */
  GameObject(float x_, float y_, int minFrame_, int maxFrame_, String fileName_) {
    loc =  new PVector(x_, y_);
    vel =  new PVector();
    acc =  new PVector();
    des =  new PVector();

    frames = new PImage[maxFrame_ - minFrame_];
    for (int c = 0; c < maxFrame_- minFrame_; c++)
      frames[c] = loadImage(fileName_+nf(c+minFrame_,5)+".png");

    // defualt image;
    img = frames[0];
  }

  /**
   * Star an gameObject up with location and the usage of image array reference
   * @param x_ the X locaiton of the new actor
   * @param y_ the Y locaiton of the new actor
   * @param minFrame_ the min frame the actor can use from the image array
   * @param maxFrame_ the max frame the actor can use from the image array
   * @param frames_ the preloaded image array
   */
  GameObject(float x_, float y_, int minFrame_, int maxFrame_, PImage[] frames_) {
    loc =  new PVector(x_, y_);
    vel =  new PVector();
    acc =  new PVector();
    des =  new PVector();

    minFrame = minFrame_;
    maxFrame = maxFrame_;


    frames = frames_;

    // defualt image;
    img = frames[minFrame_];

    centralImgArray = true;
  }

  /**
   * Smoothly animate between des and loc
   * @param smoothFactor_ 0 - 1 where 1 is no smoothMove and 0 is no movment at all
   */
  public void smoothMove(float smoothFactor_) {
    float vX = des.x - loc.x;
    float vY = des.y - loc.y;

    vX *= smoothFactor_;
    vY *= smoothFactor_;

    vel = new PVector(vX, vY);
  }

  /**
   * Smoothly rotate between angle des and angle loc
   * @param smoothFactor_ 0 - 1 where 1 is no smoothRotate and 0 is no rotation at all
   */
  public void smoothRotate(float smoothFactor_) {
    // angleDes += (int)(angleDes/TWO_PI)*TWO_PI;

    // if (angleDes < 0) {
    //   angleDes += (int)(abs(angleDes)/TWO_PI)*TWO_PI+TWO_PI;
    // }

    // if (this instanceof Cam2D) {
    //   println(angleDes);
    // }

    float v = angleDes - angle;

    // go the shorter way
    if (v > PI)
      v -= 2*PI;
    if (v < -PI)
      v += 2*PI;

    angleVel = v*smoothFactor_;
  }

  /**
   * Calculate physics
   */
  public void simplePhysicsCal() {

    vel.add(acc);
    loc.add(vel);
    angleVel += angleAcc;
    angle    += angleVel;



    // vel.add(acc.copy().mult((float)deltaTo60FPS));
    // loc.add(vel.copy().mult((float)deltaTo60FPS));
    //
    // angleVel += angleAcc*deltaTo60FPS;
    // angle    += angleVel*deltaTo60FPS;
  }

  /**
   * Animate img
   * @param min_ min frame index
   * @param max_ max frame index
   * @param aniSpeed_ millisecond per frame
   * @param loop_ should the animation loop?
   * @param reverse_ should the animation be ran in reverse?
   */
  public void animate(int min_, int max_, int aniSpeed_, boolean loop_, boolean reverse_) {

    // advance frame
    if (millis() - lastMilAni > aniSpeed_) {
      if (reverse_)
        frameC--;
      else
        frameC++;

      lastMilAni = millis();
    }

    if (reverse_) {
      // the index is going in reverse
      if (frameC > max_)
        // this should not happen, but if it does, we can handle it
        frameC = max_;
      else if (loop_ && frameC < min_)
        // if it should loop, put it to the max again
        frameC = max_;
      else if (!loop_ && frameC < min_)
        // if it should not, stay at min
        frameC = min_;
    } else {
      // the index is going forward
      if (frameC < min_)
        // this should not happen, but if it does, we can handle it
        frameC = min_;
      else if (loop_ && frameC > max_)
        // if it should loop, put it to the min again
        frameC = min_;
      else if (!loop_ && frameC > max_)
        // if it should not, stay at max
        frameC = max_;
    }

    img = frames[frameC];
  }
  // useless update. put here as placeholder for future inheritance
  public void update() {
  }

  /**
   * render the gameObject. If has image, draw image. If not, draw a rectangle.
   */
  public void render() {
    pushMatrix();
    translate(loc.x, loc.y);
    rotate(angle);

    if (img != null)
      image(img, 0, 0);
    else {
      rect(0,0,100,200);
      ellipse(0,0,20,20);
    }

    popMatrix();
  }
}
/**
* The coins panel at the top right of the screen.
*
* @author  Donny Wu
* @version 1.0
*/
class Gui extends Menu{
  PImage scoreImage;

  /**
   * Updates the GUI
   */
  Gui() {
    super();
    scoreImage = loadImage("Sprits/ScoreGUI.png");
  }
  /**
   * Updates the GUI
   */
  public @Override
  void update() {
    smoothMove(0.25f);
    for (int c = 0; c < updatePhysics; c++) {
      simplePhysicsCal();
    }

    offLoc = new PVector(0,-scoreImage.height*1.01f);

    if (on) {
      des = onLoc;
    }
    else {
      des = offLoc;
    }

  }
  /**
   * Renders the GUI
   */
  public @Override
  void render() {
    if (loc.y >= -scoreImage.height) {
      pushMatrix();
      translate(loc.x+width-scoreImage.width/2,loc.y+scoreImage.height/2);
      tint(red(dynamicColor), green(dynamicColor), blue(dynamicColor),255*0.875f);
      image(scoreImage,0,0);

      fill(dynamicColor);
      textSize(32);
      textAlign(CENTER,CENTER);
      text("Coins:"+nf(world.score,5), 10, 0);

      popMatrix();
    }
  }
}
/**
* This class reads a image file and saves it as a level 2D array ram for the
* world to copy over. The main part of the level loader is inside the main sketch
* because of multitreading.
*
* @author  Donny Wu
* @version 1.0
*/
class LevelReader{

  int blank = color(255,255,255);
  int outlineGray = color(236,236,236);
  int normalBlock = color(0,0,0);

  int noCBlock = color(37,37,37);
  int checkpointFlag = color(0,0,255);

  int positive = color(0,255,0);
  int positiveO = color(0,255,255);
  int negative = color(100,100,100);
  int death = color(255,0,0);
  int coin = color(255,255,0);
  int win = color(255,0,255);

  float platformSize = 50;

  final int TILE_SIZE = 3;

  float cBoxDelta = 0;

  PImage[] platformFrames;
  String platformFileName = "Sprits/PlatformAnimation/Platform_";
  int platformFramesFNum = 452;

  PImage[] platformOFrames;
  String platformOFileName = "Sprits/PlatformAnimation/PlatformO_";
  int platformOFramesFNum = 450;

  PImage[] platformSFrames;
  String platformSFileName = "Sprits/PlatformAnimation/PlatformS_";
  int platformSFramesFNum = 31;

  PImage[] checkPointSave;
  String checkPointSaveName = "Sprits/PlatformAnimation/SaveBlock_";
  int checkPointSaveFNum = 30;

  PImage img;

  PImage coinImage;

  Actor[][] level;

  float percentDone = -1;
  int doneCount;
  int finishingPoint;

  String levelFileName;

  public void startLevelReader(String fileName_) {

    coinImage = loadImage("Sprits/Coin.png");

    levelFileName = fileName_;
    thread("readLevel");
  }

  // the read level method should and used to be in here, but it can't be accessed with the thread() method. so.... moved to the main sketch file. How sad eh?

}
/**
* Base code for a menu object. It can go up and out of the way, or down to cover the whole screen.
*
* @author  Donny Wu
* @version 1.0
*/
class Menu extends GameObject {


  PVector offLoc = new PVector(0,-height*1.01f);
  PVector onLoc = new PVector(0,0);

  boolean on;

  /**
   * Start a new menu
   */
  Menu () {
    super();
  }



  /**
   * Updates the menu
   */
  public @Override
  void update() {
    smoothMove(0.25f);
    for (int c = 0; c < updatePhysics; c++) {
      simplePhysicsCal();
    }

    offLoc = new PVector(0,-height*1.01f);

    if (on) {
      des = onLoc;
    }
    else {
      des = offLoc;
    }

  }
  /**
   * Renders the menu
   */
  public @Override
  void render() {
    if (loc.y >= -height) {
      pushMatrix();
      translate(loc.x+width/2,loc.y+height/2);
      fill(red(dynamicColor)/16, green(dynamicColor)/16, blue(dynamicColor)/16,255*0.875f);

      rect(0,0,width,height);


      // if (world.lr.finishingPoint != 0)
      //   rect(0,0,width*((float)world.lr.doneCount/world.lr.finishingPoint),height);

      popMatrix();
    }
  }
}
/**
* Menu that shows when the player dies. Random deathmessages will show up.
*
* @author  Donny Wu
* @version 1.0
*/
class MenuDeath extends Menu {
  // button
  Button b;
 // the last staet of on
  boolean lastOn;
  // death messages
  String[] deathMessages = {"Your timing was off.",
                            "You\u2019re worse than the\ndeveloper of this game.",
                            "The death block\u2026\nwas too powerful\u2026",
                            "You ran into a block,\nthe only way\nyou can end it.",
                            "Poor cube, you failed.",
                            "You're a sad cube.",
                            "If you want to\nrun into a block, don\u2019t\naccidentally do it. ",
                            "If the objective\nis to fail, then do it\nin the beginning.",
                            "You went far,\nbut not far enough.",
                            "Keep trying,\nbut you\u2019ll fail\nin the process.",
                            "Get good.",
                            "Have you ever tried\nUncle Fatih's man?\nOh man, this best pizza",
                            "This might just be\neasier if you just open\nyour eyes dude."};

  String text = "DEAD";

  MenuDeath () {
    super();
    b = new Button(new PVector(0,100), new PVector(225,50));
    b.text = "retry?";
  }
  /**
   * Updates the menu
   */
  public @Override
  void update() {
    super.update();
    b.renderingLoc = new PVector(loc.x+width/2,loc.y+height/2);
    b.update();

    if (b.clicked)
      on = false;

    if (!lastOn && on) {
      text = deathMessages[(int)random(deathMessages.length)]+"\nCoins:"+nf(world.score,5);
      bgMusicTIN.rewind();
      bgMusicTIN.skip(bgMusic.position()*2);
      bgMusic.pause();
      bgMusicTIN.loop();
    } else if (lastOn && !on) {

      // pause the tinny music
      bgMusicTIN.pause();

      if (checkpointState == -1) {
        // default starting position
        world.resetWorld(new CheckPoint(new PVector(0,0), 0));
      } else {
        world.resetWorld(checkpoints[checkpointState]);
      }
    }

    lastOn = on;
  }
  /**
   * Renders the menu
   */
  public @Override
  void render() {
    if (loc.y >= -height) {
      pushMatrix();
      translate(loc.x+width/2,loc.y+height/2);
      fill(red(dynamicColor)/16, green(dynamicColor)/16, blue(dynamicColor)/16,255*0.875f);

      rect(0,0,width,height);

      fill(dynamicColor);
      textSize(50);
      textAlign(CENTER,BOTTOM);
      text(text, 0, 0);

      b.render();
      // if (world.lr.finishingPoint != 0)
      //   rect(0,0,width*((float)world.lr.doneCount/world.lr.finishingPoint),height);

      popMatrix();
    }

  }
}
/**
* Menu that shows when the game is loading
*
* @author  Donny Wu
* @version 1.0
*/
class MenuLoading extends Menu{

  /**
   * Updates the menu
   */
  MenuLoading () {
    super();
  }

  /**
   * Updates the menu
   */
  public @Override
  void update() {
    super.update();
  }

  /**
   * Renders the menu
   */
  public @Override
  void render() {
    if (loc.y >= -height) {
      pushMatrix();
      translate(loc.x+width/2,loc.y+height/2);
      fill(red(dynamicColor)/16, green(dynamicColor)/16, blue(dynamicColor)/16);

      rect(0,0,width,height);


      if (world.lr.finishingPoint != 0) {
        float percent = (float)world.lr.doneCount/world.lr.finishingPoint;

        // draw the loading bar
        fill(red(dynamicColor)/3, green(dynamicColor)/3, blue(dynamicColor)/3);
        rect(0,0,width*percent,height/2);

        fill(red(dynamicColor)/8, green(dynamicColor)/8, blue(dynamicColor)/8,255*0.875f);
        textSize(50);
        textAlign(CENTER,BOTTOM);
        text((int)(percent*100)+"%", 0, 0);
        textAlign(CENTER,TOP);
        textSize(32);

        text("Loading...", 0, 0);

        // if loading is done, start the game sunny!
        if (percent >= 1) {
          on = false;
        }
      }

      popMatrix();
    }

  }
}
/**
* Menu that shows when the player pressed pause or at the start of the game.
*
* @author  Donny Wu
* @version 1.0
*/
class MenuPause extends Menu {
  // button
  Button b;
  // pausemenu text
  String text = "";
  // the last staet of on
  boolean lastOn;

  /**
   * Updates the menu
   */
  MenuPause () {
    super();
    b = new Button(new PVector(0,100), new PVector(225,50));
    b.text = "";
  }

  /**
   * Updates the menu
   */
  public @Override
  void update() {
    super.update();
    b.renderingLoc = new PVector(loc.x+width/2,loc.y+height/2);
    b.update();
    if (b.clicked)
      on = false;

    if (!on && b.text.equals(introButton)) {
      text = "Paused";
      b.text = "resume";
    }

    if (!lastOn && on) {
      bgMusicTIN.rewind();
      bgMusicTIN.skip(bgMusic.position()*2);
      bgMusic.pause();
      bgMusicTIN.loop();
    } else if (lastOn && !on) {
      // pause the tinny music
      bgMusic.rewind();
      bgMusic.skip(bgMusicTIN.position()/2);
      bgMusicTIN.pause();
      bgMusic.loop();
    }

    lastOn = on;
  }
  /**
   * Renders the menu
   */
  public @Override
  void render() {
    if (loc.y >= -height) {
      pushMatrix();
      translate(loc.x+width/2,loc.y+height/2);
      fill(red(dynamicColor)/16, green(dynamicColor)/16, blue(dynamicColor)/16,255*0.875f);

      rect(0,0,width,height);

      fill(dynamicColor);
      textSize(50);
      textAlign(CENTER,BOTTOM);
      text(text, 0, 0);

      b.render();
      // if (world.lr.finishingPoint != 0)
      //   rect(0,0,width*((float)world.lr.doneCount/world.lr.finishingPoint),height);

      popMatrix();
    }

  }
}
/**
* Menu that shows when the player wins
*
* @author  Donny Wu
* @version 1.0
*/
class MenuWin extends Menu {
  // button
  Button b;
  // win text
  String text = "Congratulations!";
  // the last staet of on
  boolean lastOn;
  /**
   * Updates the menu
   */
  MenuWin () {
    super();
    b = new Button(new PVector(0,100), new PVector(550,50));
    b.text = "Erase Checkpoints";
  }
  /**
   * Updates the menu
   */
  public @Override
  void update() {
    super.update();
    b.renderingLoc = new PVector(loc.x+width/2,loc.y+height/2);
    b.update();
    if (b.clicked) {
      on = false;
    }

    if (lastOn && !on) {
      checkpointState = -1;
      world.resetWorld(new CheckPoint(new PVector(0,0),0));
      world.menuPause.on = true;
      world.menuPause.text = intro;
      world.menuPause.b.text = introButton;
    }

    lastOn = on;
  }

  /**
   * Renders the menu
   */
 public @Override
  void render() {
    if (loc.y >= -height) {
      pushMatrix();
      translate(loc.x+width/2,loc.y+height/2);
      fill(red(dynamicColor)/16, green(dynamicColor)/16, blue(dynamicColor)/16,255*0.875f);

      rect(0,0,width,height);

      fill(dynamicColor);
      textSize(50);
      textAlign(CENTER,BOTTOM);
      text(text+"\nYou've won with\n"+world.score+" coins.", 0, 0);

      b.render();
      // if (world.lr.finishingPoint != 0)
      //   rect(0,0,width*((float)world.lr.doneCount/world.lr.finishingPoint),height);

      popMatrix();
    }

  }
}
/**
* This class is called platform, but it is much more than that. It can be trigger blocks too
* Things like checkpoint flags are made using a confiuration of platform atributs.
*
* @author  Donny Wu
* @version 1.0
*/
class Platform extends Actor {
  // tells the collided object if the platform have gravity on that face.
  boolean gTop, gLeft, gRight, gBottom;
  // the tag of the platform. it can have different effects on the player, like death or win
  String tag;

  /**
   * Star an gameObject up with location
   * @param x_ the X locaiton of the player
   * @param y_ the Y locaiton of the player
   * @param angle_ angle of the platform
   */
  Platform(float x_, float y_, float angle_) {
    super(x_,y_);

    angle = angle_;
    cTop = 50;
    cBottom = 50;
    cLeft = 50;
    cRight = 50;

    // println(gTop+""+gLeft+""+gRight+""+gBottom);
  }

  /**
   * Star an gameObject up with location
   * @param x_ the X locaiton of the player
   * @param y_ the Y locaiton of the player
   * @param angle_ the angle of the platform
   * @param minFrame_ the min frame the platform can use
   * @param maxFrame_ the max frame the platform can use
   * @param frames_ get the reference of the image array
   */
  Platform(float x_, float y_, float angle_, int minFrame_, int maxFrame_, PImage[] frames_) {
    super(x_, y_, minFrame_, maxFrame_, frames_);

    loc.x = x_;
    loc.y = y_;
    angle = angle_;
    cTop = 50;
    cBottom = 50;
    cLeft = 50;
    cRight = 50;

    // println(gTop+""+gLeft+""+gRight+""+gBottom);
  }

  /**
   * animates the platform
   */
  public @Override
  void update() {
    if (frames != null && centralImgArray == true)
      animate(minFrame, maxFrame, 1000/60, true, false);
  }

  /**
   * Render the platform with tint
   */
  public @Override
  void render() {
    pushMatrix();
    translate(loc.x, loc.y);
    rotate(angle);


    if (tag != null) {
      if (tag.equals("DEATH")) {
        tint(255,0,0);
      } else if (tag.equals("O")) {
        // bitshift, faster.
        tint((dynamicColor >> 16) & 0xFF,
            (dynamicColor >> 8) & 0xFF,
            dynamicColor & 0xFF);
      } else {

        int checkpointNum = -1;
        // if the tag is pure number, this should not crash, but if it does, it is not a checkpoint
        try {
          checkpointNum = Integer.parseInt(tag);
        } catch (Exception e) {
          // do nothing...
        }
        // if it is not -1, it means it is a real checkpoint. so render it like a checkpoint
        if (checkpointNum != -1 && checkpointNum <= checkpointState) {
          tint(0,255,0);
        }

      }
    } else {
      // the normal tint for a block
      // bitshift, faster.
      tint((dynamicColor >> 16) & 0xFF,
          (dynamicColor >> 8) & 0xFF,
          dynamicColor & 0xFF);
    }



    if (img == null) {
      rect(0,0,cLeft+cRight,cBottom+cTop);
    } else {
      image(img,0,0);
    }


    noTint();

    popMatrix();

  }

}
/**
* Player object. Uses input from the keyboard
*
* @author  Donny Wu
* @version 1.0
*/
class Player extends Actor {

  int jumpCount;
  int jumpDuration;
  int jumped;

  // float jumpHeight;
  // float groundLevel;

  boolean dead;

  boolean lastUpHold;

  boolean lastGrounded;

  /**
   * Star an gameObject at 0,0
   */
  Player() {
    super();
    img = loadImage("Player.png");

    cTop = img.height/2;
    cBottom = img.height/2;
    cLeft = img.width/2;
    cRight = img.width/2;

    jumpDuration = 5;
  }

  /**
   * Star an gameObject up with location
   * @param x_ the X locaiton of the player
   * @param y_ the Y locaiton of the player
   */
  Player(float x_, float y_, float gravityDirection_) {
    super(x_,y_);

    angle = gravityDirection_;
    angleDes = gravityDirection_;

    gravityDirection = gravityDirection_;

    img = loadImage("Player.png");

    cTop = img.height/2;
    cBottom = img.height/2;
    cLeft = img.width/2;
    cRight = img.width/2;

    jumpDuration = 5;
  }

  /**
   * Updates the player
   */
  public @Override
  void update() {

    // even if fps goes below 60fps, physics still goines at 60fps
    for (int c = 0; c < updatePhysics; c++) {
      simplePhysicsCal();
      movementController(inputController());
      collisionController();
    }
    // println(vel.x+" "+vel.y);
    smoothRotate(0.25f);

    for (Actor a : collidedPlatforms){
      Platform p = (Platform)a;

      // ellipse(p.loc.x,p.loc.y,120,120);

      if (p.tag != null)  {
        if (p.tag.equals("WIN")) {
          world.menuWin.on = true;
        } else if (p.tag.equals("DEATH")) {
          dead = true;
        }

      }

    }
    // hanlde all trigger objects
    for (Actor a : triggerObjects) {

      if (a instanceof Platform) {
        Platform p = (Platform)a;

        int checkpointNum = -1;

        try {
          checkpointNum = Integer.parseInt(p.tag);
        } catch (Exception e) {
          // do nothing...
        }

        if (checkpointNum != -1 && checkpointNum > checkpointState) {
          checkpointState = checkpointNum;
          checkpoints[checkpointNum].score = world.score;
          checkpoints[checkpointNum].musicLoc = bgMusic.position();
        }
      }



    }
    lastGrounded = grounded;
  }

  /**
   * Checks if the player can jump
   * @return boolean can the player jump right now??
   */
  public boolean canJump() {
    return jumpCount < jumpDuration && jumped < 1;
  }

  /**
   * Handles keyboard inputs
   * @return a PVector with keyboard inputs
   */
  public PVector inputController() {
    PVector input = new PVector();


    if (!upHold && lastUpHold) {
      jumped++;
    }

    lastUpHold = upHold;

    if (grounded) {
      jumpCount = 0;
      jumped = 0;
      // groundLevel = loc.copy().rotate(-gravityDirection).y;
      // jumpHeight = 0;
    }

    if (upHold) {
      if (canJump()) {
        input.y -= 1;
        jumpCount++;
        }
    }


    // if (downHold)
    //   input.y += 1;
    // if (leftHold)
    //   input.x -= 1;
    // if (rightHold)
    //   input.x += 1;

    if (downHold)
      input.y += 0.3f;
    if (leftHold)
      input.x -= 0.5f;
    if (rightHold) {
      input.x += 1.5f;
    } else {
      input.x += 1;
    }

    // right key is always held down

    // input.normalize;
    // println(input);
    return input;
  }

  /**
   * Controls movement and gravity
   * @param input uses the input and moves the player
   */
  public void movementController(PVector input) {

    input.mult(5);

    input.y += world.gravity;

    acc = input.rotate(gravityDirection);

    acc.rotate(-gravityDirection);

    float aX = -vel.copy().rotate(-gravityDirection).x;
    float aY = -vel.copy().rotate(-gravityDirection).y;

    aX *= 0.4f;
    aY *= 0.02f;

    acc.add(new PVector(aX, aY));

    acc.rotate(gravityDirection);
  }


}
/**
* Contians the world and its functions, like menus, constant gravity force,
* camera, and much more.
*
* @author  Donny Wu
* @version 1.0
*/
class World {

  // the storeage for the current frame's onscreen patforms
  ArrayList<Platform> platforms = new ArrayList<Platform>();

  // the whole level, returned by the level reader
  Actor[][] level;
  // the player
  Player player;
  // the camera
  Cam2D camera;

  // constant gravity
  float gravity;

  // values for the start delay at the end of pause menu, death menu, and checkpoint reset.
  int lastStartDelay;
  int startDelay;

  // get all of the menus working
  MenuLoading menuLoading;
  MenuDeath menuDeath;
  MenuPause menuPause;
  Gui gui;
  MenuWin menuWin;

  // the level reader
  LevelReader lr;

  // the zhold state in the last frame
  boolean oldZHold;
  // the xhold state in the last frame
  boolean oldXHold;
  // if the world should reload from file
  boolean shouldReload;
  // the score, as in coins
  int score;

  /**
   * start a world in the center
   */
  World() {
    // make a new level reader
    lr = new LevelReader();
    // set the delay to 250
    startDelay = 250;

    // set global gravity force
    gravity = 1;
    // make a new player
    player = new Player();
    // make a new camera that centers at player's location
    camera = new Cam2D(player.loc.x,player.loc.y, 0);

    // make all the new menus
    menuLoading = new MenuLoading();
    menuDeath = new MenuDeath();
    menuPause = new MenuPause();
    gui = new Gui();
    menuWin = new MenuWin();

    // set should load level to true;
    shouldReload = true;

    //set current millis to the last start delay so it knows when to count down
    lastStartDelay = millis();
  }

  /**
   * updates the world in every frame
   */
  public void update() {
    // set the background to the 8th the brightness of the dynamicColor for a dark background
    background(red(dynamicColor)/8, green(dynamicColor)/8, blue(dynamicColor)/8);

    // let the camera do its thing.
    pushMatrix();



    // update the camera
    camera.des = new PVector(-player.loc.x,-player.loc.y);
    camera.angleDes = -player.gravityDirection;
    camera.update();

    if (lr.percentDone == -1) {
      // if percetn done is -1, that means the level reader has not been ran before
      lr.startLevelReader("Sprits/MainMap.png");
      lr.percentDone = 0;
    }

    if (!menuLoading.on) {
      // if the the menu loading is not on, it means loading is over and the world can function

      if (millis() - lastStartDelay > startDelay && !menuPause.on && !menuLoading.on && !menuDeath.on && !menuWin.on) {
        // if no menus are on
        // a little delay before the player starts moving.
        player.update();

        // is holding the reset key. RESET.
        if (xHold && !oldXHold) {
          lastStartDelay = millis();
          if (checkpointState == -1) {
            // default starting position
            world.resetWorld(new CheckPoint(new PVector(0,0), 0));
          } else {
            world.resetWorld(checkpoints[checkpointState]);
          }
        }
      }

      // if the gui should show up or not
      if (!menuLoading.on && !menuDeath.on)
        gui.on = true;
      else
        gui.on = false;

      // if should reaload, reload the level array from the level reader
      if (shouldReload) {
        copyLevelOver(lr.level);
        shouldReload = false;
      }

      if (player.dead && !menuDeath.on) {
        // dead, so get on it and turn on the death menu.
        menuDeath.on = true;
      }


      // draw the minimap backgournd
      drawBackgroundMinmap();

      // clear the temp arraylist for platforms
      platforms.clear();
      // whole drawing the screen, it will fill in the platforms arraylist
      onScreenObjectsManager();

    }

    // render the player with a tint
    playerRenderTint();

    // close camera influence
    popMatrix();

    // check dismiss menu or pause
    if (zHold && !oldZHold && !menuLoading.on) {
      if (menuDeath.on)
        menuDeath.on = false;
      else if (menuWin.on)
        menuWin.on = false;
      else
        menuPause.on = menuPause.on ? false : true;
      lastStartDelay = millis();
    }

    // update all menus
    gui.update();
    gui.render();
    menuLoading.update();
    menuLoading.render();
    menuDeath.update();
    menuDeath.render();
    menuPause.update();
    menuPause.render();
    menuWin.update();
    menuWin.render();

    // update old to new.
    oldZHold = zHold;
    oldXHold = xHold;
  }

  /**
   * Copies an external level into the world
   * @param level_ a 2D array that contains level info
   */
  public void copyLevelOver(Actor[][] level_) {

    level = new Actor[level_.length][level_[0].length];

    for (int x = 0; x < level_.length; x++) {
      for (int y = 0; y < level_[0].length; y++ ) {
        level[x][y] = level_[x][y];
      }
    }
  }


  /**
   * go through and loads only the ones that the player may see on screen
   * uses dynamic loading system that maps the player's location to an 2d Level array
   */
  public void onScreenObjectsManager() {

    // map the player location to the 2D array location
    PVector topLeft     = locToArrayIndex(new PVector(player.loc.x-max(width,height)+width/4,
                                                      player.loc.y-max(width,height)+width/4));
    PVector bottomRight = locToArrayIndex(new PVector(player.loc.x+max(width,height)+width/4,
                                                      player.loc.y+max(width,height)+width/4));

    // find the start and end of this box
    int xStart = (int)(topLeft.x > 0 ? topLeft.x : 0);
    int xEnd = (int)(bottomRight.x < level.length ? bottomRight.x : level.length);
    int yStart = (int)(topLeft.y > 0 ? topLeft.y : 0);
    int yEnd = (int)(bottomRight.y < level[0].length ? bottomRight.y : level[0].length);

    // loop though the whole thing
    for (int y = yStart; y < yEnd; y++) {
      for (int x = xStart; x < xEnd; x++) {
        Actor a = level[x][y];
        if (a != null) {
          if (a instanceof Platform) {
            Platform p = (Platform)a;

            // this is a no collision block, for decoration, so just render it
            if (p.collisionMode == p.NOC) {
              p.render();
            } else {
              platforms.add(p);
              p.update();
              p.render();
            }
          } else if (a instanceof Coin) {
            if (player.collision(a)) {
              // if player is touching the coin, remove it and score
              landSound.rewind();
              landSound.play();
              score++;
              level[x][y] = null;
            } else {
              a.update();
              noTint();
              a.render();
            }
          }
        }
      }
    }
  }

  /**
   * draws the player with a tint
   */
  public void playerRenderTint() {
    // bitshift, faster.
    tint((dynamicColor >> 16) & 0xFF,
        (dynamicColor >> 8) & 0xFF,
        dynamicColor & 0xFF);
    player.render();
    noTint();
  }

  /**
   * draws the backgorund minimap. It is o.5x version of the real platform
   * this draws the background using rect() I did not use an image for this
   * beuase it makes no sense ot store a blank image and then draw it.
   */
  public void drawBackgroundMinmap() {
    // map the player location to the 2D array location
    PVector topLeft     = locToArrayIndex(new PVector(player.loc.x-max(width*2,height*2)+width/4,
                                                      player.loc.y-max(width*2,height*2)+width/4));
    PVector bottomRight = locToArrayIndex(new PVector(player.loc.x+max(width*2,height*2)+width/4,
                                                      player.loc.y+max(width*2,height*2)+width/4));

    // find the start and end of this box
    int xStart = (int)(topLeft.x > 0 ? topLeft.x : 0);
    int xEnd = (int)(bottomRight.x < level.length ? bottomRight.x : level.length);
    int yStart = (int)(topLeft.y > 0 ? topLeft.y : 0);
    int yEnd = (int)(bottomRight.y < level[0].length ? bottomRight.y : level[0].length);

    fill(red(dynamicColor)/4, green(dynamicColor)/4, blue(dynamicColor)/4);
    // grab all the real platofrm and draw it
    for (int y = yStart; y < yEnd; y++) {
      for (int x = xStart; x < xEnd; x++) {
        Actor a = level[x][y];
        if (a != null) {
          if (a instanceof Platform) {
            Platform p = (Platform)a;

            pushMatrix();
            translate(p.loc.x/2+player.loc.x/2, p.loc.y/2+player.loc.y/2);
            rotate(p.angle);
            rect(0,0,(p.cLeft+p.cRight)/2,(p.cTop+p.cBottom)/2);
            popMatrix();
          }
        }
      }
    }
  }

  /**
   * Maps the location of the player to the level 2D array
   * @param loc_ players location
   */
  public PVector locToArrayIndex(PVector loc_) {
    float pX = loc_.x/(lr.platformSize*2)+level.length/2;
    float pY = loc_.y/(lr.platformSize*2)+level[0].length/2;

    return new PVector(pX,pY);
  }

  /**
   * Copies an external level into the world
   * @param cp check point object that that contains the repswn point
   */
  public void resetWorld(CheckPoint cp) {
    player = new Player(cp.loc.x,cp.loc.y,cp.angle);
    score = cp.score;
    bgMusic.rewind();
    bgMusic.skip(cp.musicLoc);
    bgMusic.loop();
    shouldReload = true;
  }
}
  public void settings() {  size(1280,720,P2D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "assignment4" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
